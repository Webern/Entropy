// Copyright (c) Matthew James Briggs

#pragma once

#include "Entropy/Enums.h"
#include <string>

namespace entropy
{
	/// @brief TODO
	///
	/// @detailed TODO
	///
    class ___FILEBASENAME___
    {
    public:
    	___FILEBASENAME___();

    public:
    	void pubicFunc() const;

    private:
    	int myInt;

    private:
        void privateFunc();
        
    };
}
