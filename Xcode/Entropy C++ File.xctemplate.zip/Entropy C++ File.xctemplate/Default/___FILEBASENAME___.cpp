// Copyright (c) Matthew James Briggs

namespace entropy
{

}
