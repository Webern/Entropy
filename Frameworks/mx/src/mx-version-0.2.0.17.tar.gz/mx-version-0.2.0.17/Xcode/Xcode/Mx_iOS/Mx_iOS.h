//
//  Mx_iOS.h
//  Mx_iOS
//
//  Created by mjb on 3/15/17.
//  Copyright © 2017 Matthew James Briggs. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Mx_iOS.
FOUNDATION_EXPORT double Mx_iOSVersionNumber;

//! Project version string for Mx_iOS.
FOUNDATION_EXPORT const unsigned char Mx_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mx_iOS/PublicHeader.h>


