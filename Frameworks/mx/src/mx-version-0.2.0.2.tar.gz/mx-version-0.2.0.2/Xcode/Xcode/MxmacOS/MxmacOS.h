//
//  MxmacOS.h
//  MxmacOS
//
//  Created by mjb on 3/15/17.
//  Copyright © 2017 Matthew James Briggs. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for MxmacOS.
FOUNDATION_EXPORT double MxmacOSVersionNumber;

//! Project version string for MxmacOS.
FOUNDATION_EXPORT const unsigned char MxmacOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MxmacOS/PublicHeader.h>


