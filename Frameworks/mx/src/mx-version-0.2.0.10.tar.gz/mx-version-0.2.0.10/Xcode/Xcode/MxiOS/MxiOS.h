//
//  MxiOS.h
//  MxiOS
//
//  Created by mjb on 3/15/17.
//  Copyright © 2017 Matthew James Briggs. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MxiOS.
FOUNDATION_EXPORT double MxiOSVersionNumber;

//! Project version string for MxiOS.
FOUNDATION_EXPORT const unsigned char MxiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MxiOS/PublicHeader.h>


