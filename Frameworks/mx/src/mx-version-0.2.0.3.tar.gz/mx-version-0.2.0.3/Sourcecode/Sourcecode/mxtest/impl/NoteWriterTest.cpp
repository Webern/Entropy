// MusicXML Class Library
// Copyright (c) by Matthew James Briggs
// Distributed under the MIT License

#include "mxtest/control/CompileControl.h"
#ifdef MX_COMPILE_IMPL_TESTS
#include "cpul/cpulTest.h"
#include "mx/core/elements/NoteAttributes.h"
#include <memory>

using namespace mx;
using namespace mx::core;

TEST( sdfsdf, MagicTemplates )
{

}
T_END

#endif
